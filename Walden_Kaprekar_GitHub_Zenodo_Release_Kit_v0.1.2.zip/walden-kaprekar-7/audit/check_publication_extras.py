#!/usr/bin/env python3
"""Extra finite regression checks; not a substitute for the general proof."""
from pathlib import Path
import sys, zipfile, tempfile, importlib.util
root = Path(__file__).resolve().parents[1]
archive = root / 'artifacts' / 'CP_KAP307_COMPLETE_CANDIDATE_2026-11-20.zip'
with tempfile.TemporaryDirectory() as d:
    p = Path(d) / 'finite307.py'
    with zipfile.ZipFile(archive) as f:
        p.write_bytes(f.read('CP_KAP307_COMPLETE_CANDIDATE/finite307.py'))
    spec = importlib.util.spec_from_file_location('finite307', p)
    f = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(f)
    count = maximum = 0
    for b in range(22, 36):
        nodes = [(x,y,z) for x in range(1,b) for y in range(x+1) for z in range(y+1)]
        for cyc in f.cycles(nodes, lambda g: f.full(g,b)):
            for g in cyc:
                v = f.V(f.p(g,b)); assert v <= 15, (b,g,v)
                count += 1; maximum = max(maximum,v)
    for h in range(11,257):
        b = 2*h
        assert f.full((h,h,0),b) == (h,h,h-1)
        assert f.full((h+1,h,0),b) == (h,h,h)
        for y in (h-1,h):
            for s in range(1,h):
                assert f.full((h,y,s),b) == (2*h-s,h-s,0)
    print('PASS even-base zero predecessors for h=11..256; positive-z gate images agree.')
    print('PASS small-base cycle points',count,'max 4V',maximum)
