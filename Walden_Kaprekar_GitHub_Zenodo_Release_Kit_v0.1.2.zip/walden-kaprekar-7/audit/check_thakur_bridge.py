"""Exact small-base bridge for the Thakur corollary; Python 3 stdlib only."""
from itertools import product

def add(a,b): return tuple(x+y for x,y in zip(a,b))
def digits(g,b):
    x,y,z = g
    n = sum(d*(b**(6-i)-b**i) for i,d in enumerate(g))
    ds=[]
    for _ in range(7):
        n,d=divmod(n,b); ds.append(d)
    assert n==0
    return tuple(sorted(ds,reverse=True))
def step(g,b):
    d=digits(g,b)
    return tuple(d[i]-d[-i-1] for i in range(3))
def cycle_sets(b):
    nodes={(x,y,z) for x in range(1,b) for y in range(x+1) for z in range(y+1)}
    count=len(nodes); done=set(); cycles=set()
    for start in nodes:
        if start in done: continue
        path=[]; index={}; g=start
        while g not in done and g not in index:
            assert g in nodes
            index[g]=len(path); path.append(g); g=step(g,b)
        if g in index: cycles.add(frozenset(path[index[g]:]))
        done.update(path)
    assert len(done)==count
    return cycles,count

def main():
    assert __debug__, 'Run without -O'
    data={b:cycle_sets(b) for b in range(22,40)}
    points=0
    for b in range(22,36):
        old,new=data[b][0],data[b+4][0]
        phi=lambda g:add(g,(3,2,1))
        assert {frozenset(phi(g) for g in c) for c in old}==new
        for c in old:
            for g in c:
                assert step(phi(g),b+4)==phi(step(g,b))
                assert digits(phi(g),b+4)==add(digits(g,b),(4,3,3,2,2,1,1))
                points+=1
        print(f'PASS b={b} -> {b+4}; {sum(map(len,old))} periodic points')
    print(f'PASS {sum(n for _,n in data.values())} states in bases 22..39; {points} periodic-point checks in bases 22..35')
if __name__=='__main__': main()
