# Independent review checklist

This is a preprint candidate. Successful artifact checks do not by themselves establish that the elementary mathematical reductions or the proof checker are error-free. This package has not been reviewed by an independent mathematician.

| Obligation | Exact verification route |
|---|---|
| Odd zero-gate predecessor classification | `odd_rank307.py` + archived `verify_odd_parent.py`: 720 orderings, 700 contradictions, 20 affine solutions with nonzero determinant |
| Lower-dimensional boundary gates | CP268/269 `verify_gate2.py`, `verify_z1.py`: 1,181 branches each |
| Diagonal-image necessary conditions | `gate307.py`: 20 interleavings, 10 contradictions, 6 zero-t exclusions, 4 feasible branches, 16 inequalities |
| Two-step lower bound | `reverse307.py`: 400 paths, 163 contradictions and 237 bound certificates |
| Upper-start five-step drift | 32 histories, `verify307.py`, 43,011 comparisons |
| Delayed upper-entry five-step drift | 30 histories, parent CP306 checker, 73,755 comparisons |
| Large-radius central decrease | revised CP301-G, `cp302_audit_G.py`, 22 roots and 744 leaves |
| Discrete central estimate and low-radius estimate | `finite307.py`: 2,107 middle-radius, 1,013 low-radius lattice points, 185,016 finite-base low-radius states |
| Final cycle classification | `finite307.py`: 1,139 residue points and 63,175 small-base states; full orbit set comparisons |

Reviewer priorities: (a) the borrowing formulas and positive-z gate argument, including the zero-input predecessor repair; (b) exhaustiveness of sorting branch guards; (c) Farkas coefficient signs, equality and exact input semantics; (d) boundary extension for the projective vertex proof; (e) the uniform reduction to finite lattices; (f) compare full orbit sets rather than just period lengths. See the English paper for the mathematical argument and the original Japanese record for inherited details.

This package retains CP307 rather than replacing the candidate proof. The original ZIP SHA-256 is `1a68e51a4dab2783fae3b11289ede0926824297b05562b4443e5d5ebeb92828a`. The preprint is an editorial English restatement, not a new external proof check. Historical replay logs are inside the original ZIP. The publication wrapper adds exact history coverage and refuses a modified original archive. See `publication-replay.log` for a new run if present. GitHub Actions has not been run on GitHub itself.

No Lean formalization, external peer review, complete bibliographic priority audit or assigned DOI. Before publishing, inspect nested archival material for personal details and third-party rights, confirm rights, and approve the license. The named author and affiliation were supplied for version 0.1.1: Shigehisa Harada (原田重壽), Independent Researcher. This editorial revision did not rerun the proof or modify its archive.

## Publication-stage replay (2026-11-20)

`publication-replay.log` is a fresh replay, deliberately kept even though the execution environment stopped it at its time limit. It records the original archive hash check, completeness of the 32+30 region file sets, all internal file hash checks, the boundary witnesses, the 400 reverse paths, 20 diagonal branches, all finite classifications, and 30 of the 32 new upper-start history verifications as PASS. It ended with `Terminated` before the last two upper-start histories and parent verifications in that run. This is not a new complete replay. The historical CP307 full replay log in the immutable original ZIP records a success for those checks. Run `bash verify.sh` without the short execution limit to recheck the full chain. No result is inferred merely from the existence of a certificate file.

A separate exact regression calculation reconfirmed the even-base gate images for `h=11..256`, the two possible zero predecessors with `X=h`, and every small-base cycle's scaled V bound: 132 periodic points in bases 22..35, maximum 4V=14. The mathematical generalization is the elementary proof in the paper, not the finite regression. Source and output are provided by `check_publication_extras.py` and `publication-extras.log`.

## Version 0.1.2: Thakur corollary and references (2026-11-20)

The immutable CP307 archive and its SHA-256 are unchanged. The new standalone `check_thakur_bridge.py` was executed successfully: 101,286 nonzero difference states in bases 22 through 39, 14 exceptional base transitions, and 132 periodic points in bases 22 through 35. It checks complete translated cycle sets, every successor relation and the sorted-digit increment. `thakur-bridge.log` records the results. The proof for b >= 36 is the analytic conjugacy via the common centered map, conditional on the main CP307 proof. No full CP307 replay or new independent external audit was conducted in this editorial/corollary revision. The new wrapper includes the finite bridge check. The previous incomplete publication replay and original complete historical log are preserved with their original status. The literature lookup includes Thakur (2019), Section 4.3, Kay and Downes-Ward (2022, 2024 preprint), and Chen et al. (2026); no comprehensive priority claim is made.
