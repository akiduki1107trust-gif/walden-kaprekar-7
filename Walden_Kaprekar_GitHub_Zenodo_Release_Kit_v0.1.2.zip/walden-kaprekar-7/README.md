# A Computer-Assisted Proof of Walden's Seven-Digit Kaprekar Conjecture

**Version 0.1.2 — preprint draft for independent review (CP-KAP-307, 2026-11-20).** **Author:** Shigehisa Harada (原田重壽), Independent Researcher. Release licensing must be selected before public deposit. This revision preserves the original CP307 archive and adds a Thakur corollary, its supplementary finite checker, and related-work citations. This repository proposes a computer-assisted resolution of Byron L. Walden's Conjecture 4.3, not a peer-reviewed or Lean-formalized result.

## Main mathematical claim

For every integer base `b >= 22`, the nonzero periodic orbits of the seven-digit Kaprekar routine are precisely the cycles in Walden's Lemma 4.1. The base-independent localization, via the centered Lyapunov function, is `V_b(g) <= 15/4` on periodic states. The proof reduces infinitely many bases to exact finite verification on four residue lattices and a finite set of small bases.

| Base | Cycle representatives in difference coordinates | Least periods |
|---|---|---|
| 4k | (3k,2k,k); (3k,2k,k+1) | 1; 19 |
| 4k+1 | (3k+1,2k+1,k-1); (3k,2k+1,k); (3k,2k+1,k+2) | 2; 2; 4 |
| 4k-1 | (3k,2k-1,k) | 8 |
| 4k-2 | (3k,2k-1,k) | 4 |

Here k >= 6. The zero fixed point is excluded. The claim is not about arbitrary numbers of digits or every transient orbit.

## Further consequence: Thakur's 2019 base-periodicity prediction

Conditional on the CP307 proof, for every integer `b >= 22`, the translation
`Phi_b(x,y,z) = (x+3,y+2,z+1)` is a bijection between nonzero periodic sets in bases b and b+4 and commutes with the respective maps. Least periods and cycles are preserved. The sorted seven-digit outputs translate by `(4,3,3,2,2,1,1)`. The common centered map proves this for b >= 36; the new exact checker covers the 14 remaining transitions (22 through 35). This establishes the seven-digit special case of the prediction in [Thakur (2019), Section 4.3](https://people.math.rochester.edu/faculty/dthakur2/kaprekar.pdf), if the main proof is correct. It is not a result for all odd digit lengths.

Related work: [Kay and Downes-Ward (2022)](https://cs.uwaterloo.ca/journals/JIS/VOL25/Kay/kay5.html), [Kay and Downes-Ward (2024 preprint)](https://arxiv.org/abs/2408.12257), and [Chen, Ono, Schwartz and Thakur (2026)](https://cs.uwaterloo.ca/journals/JIS/VOL29/Ono/ono3.html). The latter treats four digits in odd bases, including formalization. Our literature search does not establish priority. 

## Read and reproduce

- [English preprint (PDF)](manuscript/paper.pdf) and [LaTeX source](manuscript/paper.tex)
- [Original Japanese proof record](manuscript/proof-ja.md)
- [Original CP307 archive](artifacts/CP_KAP307_COMPLETE_CANDIDATE_2026-11-20.zip) — immutable, includes all required parent artifacts.
- [Verification map and audit notes](audit/REVIEW.md)
- [Thakur finite bridge checker](audit/check_thakur_bridge.py) and [new execution log](audit/thakur-bridge.log)
- [Japanese public announcement drafts](outreach/note-ja.md) and [X posts](outreach/x-posts.md)

From an ordinary Linux shell (Python 3, Bash, unzip and sha256sum; assertions enabled):

```sh
bash verify.sh
```

The wrapper checks the original SHA-256, the exact set of region histories, and executes the original verifier. Expected terminal line:

```text
CP307 ALL CRITICAL CERTIFICATE AND FINITE CHECKS PASS
```

No solver is needed for replay; optional certificate-generation programs may need NumPy/SciPy. Exact rational identities, exact integer computations and exact polyhedral vertex tests are checked. The mathematical reduction and the checkers themselves remain open to independent scrutiny. See the paper for definitions and the scope of each proof obligation.

## Citation and releasing

The original problem: B. L. Walden, *Searching for Kaprekar's constants: algorithms and results*, IJMMS 2005 (18), 2999–3004, [doi:10.1155/IJMMS.2005.2999](https://doi.org/10.1155/IJMMS.2005.2999).

For this work, `CITATION.cff` contains the confirmed author and affiliation. The Zenodo metadata template is in `metadata/.zenodo.json.template`; select a license, verify permissions and the actual release date before activating it. No unverified ORCID is included. No DOI has been assigned to this draft. Do not use Walden's DOI as the identifier of this work. See [release instructions (Japanese)](PUBLISH_JA.md). ChatGPT assisted development and drafting; no independent peer review or formal Lean proof is claimed.
