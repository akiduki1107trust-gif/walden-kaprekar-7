# Zenodo manual deposit (paper)

Title: A Computer-Assisted Proof of Walden's Seven-Digit Kaprekar Conjecture

Resource type: Publication / Preprint (if offered in the deposition interface)

Version: 0.1.2 (review draft; update consistently if a later version is made public)

Creator: Harada, Shigehisa (原田重壽). Affiliation: Independent Researcher. ORCID: not supplied; leave blank unless verified. Date: actual date of publication. License: select only after rights and author approval. No DOI assigned yet.

Description: This preprint presents a computer-assisted proof candidate for Walden's Conjecture 4.3, concerning every nonzero periodic orbit of the seven-digit Kaprekar routine in every integer base b > 21. It uses difference coordinates, certified piecewise-affine inequalities and a five-step Lyapunov function to confine periodic points to a base-independent finite neighborhood. Exact integer enumeration on four residue lattices then recovers Walden's seven cycle families. The accompanying reproducibility artifact contains the rational certificates, checking code and historical execution logs. As a corollary, conditional on the main proof, the periodic dynamics in bases b and b+4 are conjugate via (x,y,z) -> (x+3,y+2,z+1) for every integer b >= 22, giving the seven-digit instance of Thakur’s 2019 prediction (Section 4.3). Independent peer review and Lean formalization are pending.

Keywords: Kaprekar routine; discrete dynamics; periodic orbits; Lyapunov function; rational certificates; computer-assisted proof.

References: Byron L. Walden (2005), Searching for Kaprekar's constants: algorithms and results, doi:10.1155/IJMMS.2005.2999.

Additional references: D. S. Thakur (2019), Kaprekar phenomena, Section 4.3, https://people.math.rochester.edu/faculty/dthakur2/kaprekar.pdf; A. Kay and K. Downes-Ward (2022), https://cs.uwaterloo.ca/journals/JIS/VOL25/Kay/kay5.html; their 2024 preprint, https://arxiv.org/abs/2408.12257; E. Chen et al. (2026), https://cs.uwaterloo.ca/journals/JIS/VOL29/Ono/ono3.html.

Files: author-listed paper.pdf, paper.tex, complete proof archive, verification wrapper and release instructions (or the full publication archive). If a separate GitHub/Zenodo software DOI exists, link the two records with an appropriate relationship; do not invent a DOI. The preprint DOI and archive DOI may be distinct.
