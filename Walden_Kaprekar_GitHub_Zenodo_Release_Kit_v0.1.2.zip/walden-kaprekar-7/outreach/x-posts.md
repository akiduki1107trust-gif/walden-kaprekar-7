# X投稿文（日本語・英語）

## 公開前（このまま投稿可）
2005年のWaldenの7桁カプレカ予想（基数22以上）に対する計算機援用証明候補を構成しました。2019年のThakurの予想の7桁版にも接続。論文と再現資料を公開予定です。独立検証・査読はこれから。 #数学 #カプレカ定数

## 公開後（実在するDOIのURLに置換してから投稿）
Waldenの7桁カプレカ予想（2005年）の計算機援用証明候補を公開しました。Thakurの予想（2019年）の7桁版にも接続。独立検証・査読前です。論文と再現資料：［発行済みDOIのURL］ #数学

## English, after deposit only (replace URL)
Preprint: a computer-assisted proof candidate for Walden's seven-digit Kaprekar conjecture (2005), with the seven-digit case of Thakur's 2019 base-periodicity prediction as a corollary. Independent review pending. [DOI URL]

公開済みでない場合は「公開予定」とする。GitHub URLやDOIを推測で記入しない。標準投稿の文字数上限に合わせ、実URLを追加したらプレビューで確認する。
