# 公開手順｜GitHub + Zenodo DOI

## 公開前に必ず確定すること
- 著者名は Shigehisa Harada（原田重壽）、所属表記は Independent Researcher（独立研究者）に確定済み。ORCID・連絡先は未確認のため記載しない。
- 英語論文を読んで数学的主張、引用、AI利用の記載を確認する。原稿は査読前の証明候補であり、先取権・第三者認証を断定しない。
- 文書・コード・証明書・過去の入れ子ZIPを含む配布物の権利、個人情報、第三者ライセンスを確認する。ライセンスは未選択。例として論文CC BY 4.0、コードMITがあるが、権利者が選択・承認するまで適用しない。混在する場合はそれぞれの適用範囲を明記する。
- `manuscript/paper.tex` の著者欄・PDFメタデータ・AI利用記載は更新済み。再コンパイルには XeLaTeX（xeCJK、Noto Serif CJK JP）を使う。`cd manuscript; xelatex paper.tex; xelatex paper.tex`。ORCIDやメールを勝手に作成しない。
- ルートの `CITATION.cff` は著者・所属を反映済み。`metadata/.zenodo.json.template` は著者を反映済みだがライセンスは未選択。権利者がライセンスIDを確定してからルートの `.zenodo.json` にコピーする。両方が存在する場合、ZenodoのGitHubアーカイブは `.zenodo.json` を優先する。未確定のテンプレートを有効化しない。
- GitHubに表示・Zenodoに登録する版（関連研究・Thakur系追加版は0.1.2）と実際の公開日、READMEの公開前表記を統一する。`bash verify.sh` を実行。最新版のファイルのハッシュを更新する。

## GitHubで公開
1. https://github.com/new で新規リポジトリを作る。推奨名 `walden-kaprekar-7`。最初はPrivateにし、公開前の確認後にPublicへ変更する方法が安全。
2. このZIPを展開し、ZIPの中のルートファイル（隠しファイルも含む）を追加。CLIを使う場合、公開するリポジトリのURLを実際のものに置き換え、Git認証を済ませてから以下を実行する。

```sh
git init
git add .
git commit -m "Prepare CP307 proof candidate and exact verification artifacts"
git branch -M main
git remote add origin https://github.com/YOUR_ACCOUNT/walden-kaprekar-7.git
git push -u origin main
```

GitHub Actionsの `Exact proof artifact replay` の結果も確認する。GitHubにログインした上で行う操作であり、このパッケージ作成時にはリポジトリ作成・公開は行っていない。

## DOI取得：GitHub連携でアーカイブを固定する（ソフトウェアDOIの場合）
1. https://zenodo.org/ にGitHubアカウント等でログイン。https://zenodo.org/account/settings/github/ から連携を許可し、対象Publicリポジトリを有効化。
2. GitHubの **Releases → Draft a new release** からタグ `v0.1.2` を作成（メタデータと統一）。タイトル `CP-KAP-307 — Review preprint and reproducibility artifact`。本文に査読前と記載。Zenodoの対象版アーカイブに含めたいファイルはタグ対象のコミットに入れる（リリース添付だけに頼らない）。
3. 公開設定を最終確認してリリースを発行。Zenodo上に記録が生成されたこと、DOIが発行されたこと、著者名・データ・ライセンス・バージョンが正しいことを確認する。DOIは発行後の実際の値のみ引用欄やREADMEに反映する。次の版は新タグで公開する。

## 推奨：Zenodoに論文を直接登録（論文DOIを優先する場合）
GitHub連携を使わなくてもZenodoのNew uploadから論文と完全証明資料をアップロードできる。`metadata/zenodo-preprint-en.md` に英語の入力用情報を用意した。必要に応じて公開前にDOIを予約し、原稿に記載して再PDF化できる。論文DOIとソフトウェアDOIの両方を発行する場合は相互リンクを設定する。公開後の版管理はZenodoの手順に従う。DOIは引用・永続識別の仕組みであり、科学的正しさや査読の証明ではない。

公式ガイド:
- [GitHub引用とZenodo連携](https://docs.github.com/ja/repositories/archiving-a-github-repository/referencing-and-citing-content)
- [Zenodo GitHub連携](https://help.zenodo.org/docs/github/enable-repository/)
- [Zenodo JSON](https://help.zenodo.org/docs/github/describe-software/zenodo-json/)
- [Zenodo DOI予約](https://help.zenodo.org/docs/deposit/describe-records/reserve-doi/)

## note・Xで告知
`outreach/note-ja.md` と `outreach/x-posts.md` を利用。公開前の文章と公開後の追記を区別し、実際に発行されたURLだけを記入する。
