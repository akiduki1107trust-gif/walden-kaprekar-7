#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
unset PYTHONOPTIMIZE
export PYTHONDONTWRITEBYTECODE=1
archive=artifacts/CP_KAP307_COMPLETE_CANDIDATE_2026-11-20.zip
printf '%s  %s\n' '1a68e51a4dab2783fae3b11289ede0926824297b05562b4443e5d5ebeb92828a' "$archive" | sha256sum -c -
python3 - "$archive" <<'PY'
import io,itertools,sys,zipfile,posixpath
with zipfile.ZipFile(sys.argv[1]) as z:
    assert z.testzip() is None
    files=[posixpath.basename(n) for n in z.namelist()]
    root_expected={'CP_KAP307_A'+''.join(s)+'_FARKAS_CERTS.json.gz' for s in itertools.product('AB',repeat=5)}
    assert {n for n in files if n.startswith('CP_KAP307_A') and n.endswith('_FARKAS_CERTS.json.gz')} == root_expected
    parent='CP_KAP307_COMPLETE_CANDIDATE/upstream/CP_KAP306_CERTIFIED_RESEARCH_2026-11-20.zip'
    with zipfile.ZipFile(io.BytesIO(z.read(parent))) as p:
        assert p.testzip() is None
        expected={'CP_KAP306_B'+''.join(s)+'_FARKAS_CERTS.json.gz' for s in itertools.product('AB',repeat=5) if 'A' in s[:4]}
        actual={posixpath.basename(n) for n in p.namelist() if posixpath.basename(n).startswith('CP_KAP306_B') and posixpath.basename(n).endswith('_FARKAS_CERTS.json.gz') and len(posixpath.basename(n).split('_')[2])==6}
        assert actual == expected,(actual-expected,expected-actual)
    print('PASS explicit coverage of all 32 upper-start and 30 central-start histories')
PY
python3 audit/check_thakur_bridge.py
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
unzip -q "$archive" -d "$scratch"
bash "$scratch/CP_KAP307_COMPLETE_CANDIDATE/reproduce.sh"
